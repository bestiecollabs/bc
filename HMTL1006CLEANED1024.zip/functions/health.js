export async function onRequestGet(){return new Response('{"ok":true}',{headers:{'content-type':'application/json'}})}
