# USER_NAMES

## Rules
- Lowercase, URL-safe, `makePublicCode()`-compatible.
- Unique across directory.

## Examples
- brand: acme-skincare
- creator: tiktok-acmecreator